package com.anaamalais.salescrm.Utils;

import com.anaamalais.salescrm.List.ExterioraccessoriesList;
import com.anaamalais.salescrm.List.InterioraccessoriesList;

public interface OnItemsExterioraccessoriesClickListener {
    void onItemClick(ExterioraccessoriesList exterioraccessoriesList);
}
