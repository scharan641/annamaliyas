package com.anaamalais.salescrm.List;

public class InteriorColorsList {
    private String interior_color_id;
    private String interior_color;

    public String getInterior_color_id() {
        return interior_color_id;
    }

    public void setInterior_color_id(String interior_color_id) {
        this.interior_color_id = interior_color_id;
    }

    public String getInterior_color() {
        return interior_color;
    }

    public void setInterior_color(String interior_color) {
        this.interior_color = interior_color;
    }
}
