package com.anaamalais.salescrm.List;

public class DropList {

    private String date;
    private String time;
    private String type;
    private String remark;
    private String today_remark;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getToday_remark() {
        return today_remark;
    }

    public void setToday_remark(String today_remark) {
        this.today_remark = today_remark;
    }
}
