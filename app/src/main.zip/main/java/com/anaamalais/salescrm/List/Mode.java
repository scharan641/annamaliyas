package com.anaamalais.salescrm.List;

public class Mode {
    private String mode_name;
    private String total_target;
    private String achieved_target;

    public String getMode_name() {
        return mode_name;
    }

    public void setMode_name(String mode_name) {
        this.mode_name = mode_name;
    }

    public String getTotal_target() {
        return total_target;
    }

    public void setTotal_target(String total_target) {
        this.total_target = total_target;
    }

    public String getAchieved_target() {
        return achieved_target;
    }

    public void setAchieved_target(String achieved_target) {
        this.achieved_target = achieved_target;
    }
}
