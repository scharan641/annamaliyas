package com.anaamalais.salescrm.List;

public class FiltersList {
    private String status_based_id;
    private String status_based_value;
    private String model_based_id;
    private String model_based_value;
    private String  followup_type_id;
    private String followup_type_value;

    public String getStatus_based_id() {
        return status_based_id;
    }

    public void setStatus_based_id(String status_based_id) {
        this.status_based_id = status_based_id;
    }

    public String getStatus_based_value() {
        return status_based_value;
    }

    public void setStatus_based_value(String status_based_value) {
        this.status_based_value = status_based_value;
    }

    public String getModel_based_id() {
        return model_based_id;
    }

    public void setModel_based_id(String model_based_id) {
        this.model_based_id = model_based_id;
    }

    public String getModel_based_value() {
        return model_based_value;
    }

    public void setModel_based_value(String model_based_value) {
        this.model_based_value = model_based_value;
    }

    public String getFollowup_type_id() {
        return followup_type_id;
    }

    public void setFollowup_type_id(String followup_type_id) {
        this.followup_type_id = followup_type_id;
    }

    public String getFollowup_type_value() {
        return followup_type_value;
    }

    public void setFollowup_type_value(String followup_type_value) {
        this.followup_type_value = followup_type_value;
    }
}
