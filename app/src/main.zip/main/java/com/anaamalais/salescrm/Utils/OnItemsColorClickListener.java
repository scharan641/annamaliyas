package com.anaamalais.salescrm.Utils;

import com.anaamalais.salescrm.List.ColorDataList;
import com.anaamalais.salescrm.List.VariantsAccessList;

public interface OnItemsColorClickListener {
    void onItemClick(ColorDataList colorDataList);
}
