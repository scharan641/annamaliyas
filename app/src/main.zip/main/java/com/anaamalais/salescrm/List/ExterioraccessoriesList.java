package com.anaamalais.salescrm.List;

public class ExterioraccessoriesList {

    private String exterior_acessory_id;
    private String exterior_acessory_name;
    private String exterior_acessory_price;

    public String getExterior_acessory_id() {
        return exterior_acessory_id;
    }

    public void setExterior_acessory_id(String exterior_acessory_id) {
        this.exterior_acessory_id = exterior_acessory_id;
    }

    public String getExterior_acessory_name() {
        return exterior_acessory_name;
    }

    public void setExterior_acessory_name(String exterior_acessory_name) {
        this.exterior_acessory_name = exterior_acessory_name;
    }

    public String getExterior_acessory_price() {
        return exterior_acessory_price;
    }

    public void setExterior_acessory_price(String exterior_acessory_price) {
        this.exterior_acessory_price = exterior_acessory_price;
    }
}
