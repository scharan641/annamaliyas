package com.anaamalais.salescrm.Utils;

import com.anaamalais.salescrm.List.InterioraccessoriesList;
import com.anaamalais.salescrm.List.UtilityaccessoriesList;

public interface OnItemsutilityaccessoriesClickListener {
    void onItemClick(UtilityaccessoriesList utilityaccessoriesList);
}
