package com.anaamalais.salescrm.List;

public class DropReasonsList {
    private String drop_id;
    private String drop_reason;

    public String getDrop_id() {
        return drop_id;
    }

    public void setDrop_id(String drop_id) {
        this.drop_id = drop_id;
    }

    public String getDrop_reason() {
        return drop_reason;
    }

    public void setDrop_reason(String drop_reason) {
        this.drop_reason = drop_reason;
    }
}
