package com.anaamalais.salescrm.List;

public class ModelsList {
    private String id;
    private String model;
    private String transmission;
    private String suffix;
    private String model_suffix;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getModel_suffix() {
        return model_suffix;
    }

    public void setModel_suffix(String model_suffix) {
        this.model_suffix = model_suffix;
    }
}
