package com.anaamalais.salescrm.List;

public class AnnualIncomesList {

    private String annual_income_id;
    private String annual_income;

    public String getAnnual_income_id() {
        return annual_income_id;
    }

    public void setAnnual_income_id(String annual_income_id) {
        this.annual_income_id = annual_income_id;
    }

    public String getAnnual_income() {
        return annual_income;
    }

    public void setAnnual_income(String annual_income) {
        this.annual_income = annual_income;
    }
}
