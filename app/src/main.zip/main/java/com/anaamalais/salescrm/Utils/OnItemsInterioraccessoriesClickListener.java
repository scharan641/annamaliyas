package com.anaamalais.salescrm.Utils;

import com.anaamalais.salescrm.List.ColorDataList;
import com.anaamalais.salescrm.List.InterioraccessoriesList;

public interface OnItemsInterioraccessoriesClickListener {
    void onItemClick(InterioraccessoriesList colorDataList);
}

