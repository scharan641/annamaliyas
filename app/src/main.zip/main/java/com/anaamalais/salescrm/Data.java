package com.anaamalais.salescrm;

public class Data {
    public String name;

    public Data clone(){
        return new Data();
    }
}
