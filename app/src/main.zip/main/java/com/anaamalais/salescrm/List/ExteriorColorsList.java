package com.anaamalais.salescrm.List;

public class ExteriorColorsList {
    private String exterior_color_id;
    private String exterior_color;

    public String getExterior_color_id() {
        return exterior_color_id;
    }

    public void setExterior_color_id(String exterior_color_id) {
        this.exterior_color_id = exterior_color_id;
    }

    public String getExterior_color() {
        return exterior_color;
    }

    public void setExterior_color(String exterior_color) {
        this.exterior_color = exterior_color;
    }
}
