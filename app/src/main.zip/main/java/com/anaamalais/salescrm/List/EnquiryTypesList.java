package com.anaamalais.salescrm.List;

public class EnquiryTypesList {

    private String enquiry_type_id;
    private String enquiry_type;

    public String getEnquiry_type_id() {
        return enquiry_type_id;
    }

    public void setEnquiry_type_id(String enquiry_type_id) {
        this.enquiry_type_id = enquiry_type_id;
    }

    public String getEnquiry_type() {
        return enquiry_type;
    }

    public void setEnquiry_type(String enquiry_type) {
        this.enquiry_type = enquiry_type;
    }
}
