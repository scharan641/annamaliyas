package com.anaamalais.salescrm.List;

public class InterioraccessoriesList {
    private String interior_accessory_id;
    private String interior_accessory_name;
    private String interior_accessory_price;

    public String getInterior_accessory_id() {
        return interior_accessory_id;
    }

    public void setInterior_accessory_id(String interior_accessory_id) {
        this.interior_accessory_id = interior_accessory_id;
    }

    public String getInterior_accessory_name() {
        return interior_accessory_name;
    }

    public void setInterior_accessory_name(String interior_accessory_name) {
        this.interior_accessory_name = interior_accessory_name;
    }

    public String getInterior_accessory_price() {
        return interior_accessory_price;
    }

    public void setInterior_accessory_price(String interior_accessory_price) {
        this.interior_accessory_price = interior_accessory_price;
    }
}
