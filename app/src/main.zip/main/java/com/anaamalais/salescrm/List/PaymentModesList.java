package com.anaamalais.salescrm.List;

public class PaymentModesList {
    private String payment_mode_id;
    private String payment_mode;

    public String getPayment_mode_id() {
        return payment_mode_id;
    }

    public void setPayment_mode_id(String payment_mode_id) {
        this.payment_mode_id = payment_mode_id;
    }

    public String getPayment_mode() {
        return payment_mode;
    }

    public void setPayment_mode(String payment_mode) {
        this.payment_mode = payment_mode;
    }
}
