package com.anaamalais.salescrm.List;

public class Model {
    private String mode_name;
    private String total_target;
    private String achieved_target;
    private String vehicle_image;

    public String getMode_name() {
        return mode_name;
    }

    public void setMode_name(String mode_name) {
        this.mode_name = mode_name;
    }

    public String getTotal_target() {
        return total_target;
    }

    public void setTotal_target(String total_target) {
        this.total_target = total_target;
    }

    public String getAchieved_target() {
        return achieved_target;
    }

    public void setAchieved_target(String achieved_target) {
        this.achieved_target = achieved_target;
    }

    public String getVehicle_image() {
        return vehicle_image;
    }

    public void setVehicle_image(String vehicle_image) {
        this.vehicle_image = vehicle_image;
    }
}
