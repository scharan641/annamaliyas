package com.anaamalais.salescrm.List;

public class FinancePitchList {
    private String finance_id;
    private String finance_type;

    public String getFinance_id() {
        return finance_id;
    }

    public void setFinance_id(String finance_id) {
        this.finance_id = finance_id;
    }

    public String getFinance_type() {
        return finance_type;
    }

    public void setFinance_type(String finance_type) {
        this.finance_type = finance_type;
    }
}
